﻿using App.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Data
{
    public class FighterDBContext : DbContext
    {
        public DbSet<Fighter> Fighters { get; set; }
        public DbSet<Tournament> Tournaments { get; set; }
        public DbSet<FightersSponsers> Sponsers { get; set; }


        public FighterDBContext(DbContextOptions<FighterDBContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FightersInTournament>()
                .HasKey(s => new { s.FighterId, s.TournamentId });
        }
    }

    
}
