﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public class Fighter
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Weight { get; set; }
        public int Age { get; set; }
        public List<FightersInTournament> FightersInTournaments { get; set; }
        public List<FightersSponsers> Sponsers { get; set; }

        public Fighter()
        {
            Sponsers = new List<FightersSponsers>();
            FightersInTournaments = new List<FightersInTournament>();
        }
    }
}
