﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public class FightersInTournament
    {
        public int FighterId { get; set; }
        public Fighter Fighter { get; set; }
        public Tournament Tournament { get; set; }
        public int TournamentId { get; set; }


    }
}
