﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public class FightersSponsers
    {
        public int Id { get; set; }
        public string Sponser { get; set; }
        public Fighter Fighter { get; set; }
        public int FighterId { get; set; }
    }
}
