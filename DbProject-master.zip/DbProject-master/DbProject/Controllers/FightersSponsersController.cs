﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using App.Data;
using App.Domain;

namespace DbProject.Controllers
{
    public class FightersSponsersController : Controller
    {
        private readonly FighterDBContext _context;

        public FightersSponsersController(FighterDBContext context)
        {
            _context = context;
        }

        // GET: FightersSponsers
        public async Task<IActionResult> Index()
        {
            var fighterDBContext = _context.Sponsers.Include(f => f.Fighter);
            return View(await fighterDBContext.ToListAsync());
        }

        // GET: FightersSponsers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fightersSponsers = await _context.Sponsers
                .Include(f => f.Fighter)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (fightersSponsers == null)
            {
                return NotFound();
            }

            return View(fightersSponsers);
        }

        // GET: FightersSponsers/Create
        public IActionResult Create()
        {
            ViewData["FighterId"] = new SelectList(_context.Fighters, "Id", "Id");
            return View();
        }

        // POST: FightersSponsers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Sponser,FighterId")] FightersSponsers fightersSponsers)
        {
            if (ModelState.IsValid)
            {
                _context.Add(fightersSponsers);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FighterId"] = new SelectList(_context.Fighters, "Id", "Id", fightersSponsers.FighterId);
            return View(fightersSponsers);
        }

        // GET: FightersSponsers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fightersSponsers = await _context.Sponsers.FindAsync(id);
            if (fightersSponsers == null)
            {
                return NotFound();
            }
            ViewData["FighterId"] = new SelectList(_context.Fighters, "Id", "Id", fightersSponsers.FighterId);
            return View(fightersSponsers);
        }

        // POST: FightersSponsers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Sponser,FighterId")] FightersSponsers fightersSponsers)
        {
            if (id != fightersSponsers.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fightersSponsers);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FightersSponsersExists(fightersSponsers.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FighterId"] = new SelectList(_context.Fighters, "Id", "Id", fightersSponsers.FighterId);
            return View(fightersSponsers);
        }

        // GET: FightersSponsers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fightersSponsers = await _context.Sponsers
                .Include(f => f.Fighter)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (fightersSponsers == null)
            {
                return NotFound();
            }

            return View(fightersSponsers);
        }

        // POST: FightersSponsers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fightersSponsers = await _context.Sponsers.FindAsync(id);
            _context.Sponsers.Remove(fightersSponsers);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FightersSponsersExists(int id)
        {
            return _context.Sponsers.Any(e => e.Id == id);
        }
    }
}
